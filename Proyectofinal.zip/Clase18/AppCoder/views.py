from django.shortcuts import render
from AppCoder.models import Curso , Avatar , Alumno , Profesor
from django.http import HttpResponse
from django.template import loader 
from AppCoder.forms import Curso_formulario , UserEditForm , Alumno_formulario , Profesor_formulario
from django.contrib.auth.forms import AuthenticationForm , UserCreationForm 
from django.contrib.auth import login , authenticate
from django.contrib.auth.decorators import login_required


# Create your views here.
def my_view(request):
    # Tu lógica de vista aquí
    return render(request, 'mi_template.html', {'request': request})

def inicio(request):
    return render( request , "padre.html")
    avatares = Avatar.objects.filter(user=request.user.id)
    return render(request , "padre.html" , {"url":avatares[0].imagen.url})


def alta_curso(request, nombre):
    curso = Curso(nombre=nombre , camada=234512)
    curso.save()
    texto = f"Se guardo en la base de datos el curso: {curso.nombre} {curso.camada}"
    return HttpResponse(texto)

@login_required
def ver_cursos(request):
    cursos = Curso.objects.all()
    dicc = {"cursos": cursos}
    plantilla = loader.get_template("cursos.html")
    documento = plantilla.render(dicc)
    return HttpResponse(documento)

    avatares = Avatar.objects.filter(user=request.user.id)
    return render(request , "cursos.html" , {"url":avatares[0].imagen.url})

@login_required
def ver_alumnos(request):
    alumnos = Alumno.objects.all()
    dicc = {"alumnos": alumnos}
    plantilla = loader.get_template("alumnos.html")
    documento = plantilla.render(dicc)
    return HttpResponse(documento)

@login_required
def ver_profesores(request):
    profesores = Profesor.objects.all()
    dicc = {"profesores": profesores}
    plantilla = loader.get_template("profesores.html")
    documento = plantilla.render(dicc)
    return HttpResponse(documento)

def curso_formulario(request):

    if request.method == "POST":

        mi_formulario = Curso_formulario( request.POST )

        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data

            curso = Curso( nombre=request.POST ["nombre"] , camada = request.POST["camada"] )
            curso.save()
            return render(request , "formulario.html")

    return render(request , "formulario.html")

def alta_alumno(request, nombre , apellido , email):
    alumno = Alumno(nombre=nombre , apellido=apellido , email=email)
    alumno.save()
    texto = f"Se guardo en la base de datos el alumno: {alumno.nombre} {alumno.apellido} {alumno.email}"
    return HttpResponse(texto)

def alumno_formulario(request):

    if request.method == "POST":

        mi_formulario = Alumno_formulario( request.POST )

        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data

            alumno = Alumno( nombre=request.POST ["nombre"] , apellido = request.POST["apellido"] , email= request.POST["email"])
            alumno.save()
            return render(request , "formulario_alumnos.html")

    return render(request , "formulario_alumnos.html")

def alta_profesor(request, nombre , apellido , email):
    profesor = Profesor(nombre=nombre , apellido=apellido , email=email)
    profesor.save()
    texto = f"Se guardo en la base de datos el profesor: {profesor.nombre} {profesor.apellido} {profesor.email}"
    return HttpResponse(texto)

def profesor_formulario(request):

    if request.method == "POST":

        mi_formulario = Profesor_formulario( request.POST )

        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data

            profesor = Profesor( nombre=request.POST ["nombre"] , apellido = request.POST["apellido"] , email= request.POST["email"])
            profesor.save()
            return render(request , "formulario_profesores.html")

    return render(request , "formulario_profesores.html")

def buscar_curso(request):
    return render(request, "buscar_curso.html")

def buscar(request):

    if request.GET["nombre"]:
        nombre = request.GET["nombre"]
        cursos = Curso.objects.filter(nombre__icontains= nombre)
        return render( request, "resultado_busqueda.html", {"cursos": cursos})
    else:
        return HttpResponse("Ingrese el nombre del curso")
    
def elimina_curso(request , id ):
    curso = Curso.objects.get(id=id)
    curso.delete()

    curso = Curso.objects.all()

    return render(request,  "cursos.html" , {"cursos":curso})

def editar(request , id ):
    curso = Curso.objects.get(id=id)

    if request.method == "POST":
        mi_formulario = Curso_formulario( request.POST )
        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data
            curso.nombre = datos["nombre"]
            curso.camada = datos["camada"]
            curso.save()

            curso = Curso.objects.all()
            
            return render(request , "cursos.html" , {"cursos": curso})
        
    else:
        mi_formulario = Curso_formulario(initial={"nombre": curso.nombre , "camada": curso.camada})

        return render( request , "editar_curso.html" , {"mi_formulario": mi_formulario , "curso": curso})
    
def elimina_alumno(request , id ):
    alumno = Alumno.objects.get(id=id)
    alumno.delete()

    alumno = Alumno.objects.all()

    return render(request,  "alumnos.html" , {"alumno": alumno})

def editar_alumno(request , id ):
    alumno = Alumno.objects.get(id=id)

    if request.method == "POST":
        mi_formulario = Alumno_formulario( request.POST )
        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data
            alumno.nombre = datos["nombre"]
            alumno.apellido = datos["apellido"]
            alumno.email = datos["email"]
            alumno.save()

            alumno= Alumno.objects.all()
            
            return render(request , "alumnos.html" , {"alumno": alumno})
        
    else:
        mi_formulario = Alumno_formulario(initial={"nombre": alumno.nombre , "apellido": alumno.apellido , "email": alumno.email})

        return render( request , "editar_alumno.html" , {"mi_formulario": mi_formulario , "alumno": alumno})
    


def elimina_profesor(request , id ):
    profesor = Profesor.objects.get(id=id)
    profesor.delete()

    profesor = Profesor.objects.all()

    return render(request,  "profesores.html" , {"profesor":profesor})

def editar_profesor(request , id ):
    profesor = Profesor.objects.get(id=id)

    if request.method == "POST":
        mi_formulario = Profesor_formulario( request.POST )
        if mi_formulario.is_valid():
            datos = mi_formulario.cleaned_data
            profesor.nombre = datos["nombre"]
            profesor.apellido = datos["apellido"]
            profesor.email = datos["email"]
            profesor.save()

            profesor= Profesor.objects.all()
            
            return render(request , "profesores.html" , {"profesor": profesor})
        
    else:
        mi_formulario = Profesor_formulario(initial={"nombre": profesor.nombre , "apellido": profesor.apellido , "email": profesor.email})

        return render( request , "editar_profesor.html" , {"mi_formulario": mi_formulario , "profesor": profesor})
    
def login_request(request):
    if request.method == "POST":
        form = AuthenticationForm(request , data=request.POST)

        if form.is_valid():
            usuario = form.cleaned_data.get("username")
            contra = form.cleaned_data.get("password")

            user = authenticate(username=usuario , password=contra)

            if user is not None:
                login(request , user)
                avatares = Avatar.objects.filter(user=request.user.id)
                return render( request , "inicio.html" , {"url":avatares[0].imagen.url , "mensaje": f"Bienvenido/a {usuario}", "usuario":usuario})
            else:
                return HttpResponse(f"Usuario no encontrado")
        else:
            return HttpResponse(f"FORM INCORRECTO {form}")



    form = AuthenticationForm()
    return render( request , "login.html" , {"form":form})

def register(request):

    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse("Usuario Creado")
    else:
        form = UserCreationForm()
    return render (request , "registro.html" , {"form": form})

def editarPerfil(request):
    usuario = request.user

    if request.method == "POST":
        mi_formulario = UserEditForm(request.POST)

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data
            usuario.email =informacion["email"]
            password = informacion["password1"]
            usuario.set_password(password)
            usuario.save()
            return render(request , "inicio.html")
        
    else:
        miFormulario = UserEditForm(initial={'email': usuario.email})

    return render( request , "editar_perfil.html" , {"miFormulario": miFormulario , "usuario":usuario})